import demoTest from '../../../tests/shared/demoTest';

demoTest('back-top');
