import demoTest from '../../../tests/shared/demoTest';

demoTest('locale-provider');
