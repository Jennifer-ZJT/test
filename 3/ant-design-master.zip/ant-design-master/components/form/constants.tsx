export const FIELD_META_PROP = 'data-__meta';
