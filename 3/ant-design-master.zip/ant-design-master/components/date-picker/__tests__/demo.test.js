import demoTest from '../../../tests/shared/demoTest';

demoTest('date-picker', { skip: ['locale.md'] });
